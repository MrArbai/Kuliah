import javax.swing.JOptionPane;

public class fiturdOp {
    public static void main (String [] args)
    {
    JOptionPane.showMessageDialog(null,"IniInformasi", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
    JOptionPane.showMessageDialog(null,"Ini Error", "ERORR", JOptionPane.ERROR_MESSAGE);
    JOptionPane.showMessageDialog(null,"Ini Warning!", "WARNING", JOptionPane.WARNING_MESSAGE);
    JOptionPane.showMessageDialog(null,"Ini Pertanyaan?","QUESTION", JOptionPane.QUESTION_MESSAGE);
    JOptionPane.showMessageDialog(null,"Ini Plain " , "PLAIN", JOptionPane.PLAIN_MESSAGE);
    }
}
