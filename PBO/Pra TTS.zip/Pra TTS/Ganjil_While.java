public class Ganjil_While {
    public static void main(String[] args) {
        int i = 1;
        while (i < 50) {
            System.out.print(i + " ");
            i += 2;
        }
    }
}
