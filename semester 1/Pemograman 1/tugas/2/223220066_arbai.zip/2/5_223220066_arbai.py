print("Menentukan bilangan positif, negatif, dan netral.")

x = int(input())

if x > 0:
    print("Bilangan positif")
elif x == 0:
    print("Bilangan netral")
else:
    print("Bilangan negatif")