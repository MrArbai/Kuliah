print("while")
i=1
while i <= 10:
      print("Saya belajar phyton")
      i += 1

print("for")
a=10
for i in range(a):
    print("Saya belajar phyton")