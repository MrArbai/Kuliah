<?php

 $Host = 'localhost';
 $Name = 'learn';
 $Username ='learn';
 $Password ='learn';

 $mysqli = mysqli_connect($Host, $Username, $Password, $Name);

 ?>