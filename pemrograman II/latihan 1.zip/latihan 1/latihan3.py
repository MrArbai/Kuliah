import matematika

a = 10
b = 5

hasil_penjumlahan = matematika.penjumlahan(a, b)
hasil_pengurangan = matematika.pengurangan(a, b)
hasil_perkalian = matematika.perkalian(a, b)
hasil_pembagian = matematika.pembagian(a, b)
hasil_perpangkatan = matematika.perpangkatan(a, b)
hasil_sisa_bagi = matematika.sisa_bagi(a, b)

print("Hasil penjumlahan:", hasil_penjumlahan)
print("Hasil pengurangan:", hasil_pengurangan)
print("Hasil perkalian:", hasil_perkalian)
print("Hasil pembagian:", hasil_pembagian)
print("Hasil perpangkatan:", hasil_perpangkatan)
print("Hasil sisa bagi:", hasil_sisa_bagi)
