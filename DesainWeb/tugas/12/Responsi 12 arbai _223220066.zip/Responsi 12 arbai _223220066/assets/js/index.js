$(document).ready(function () {
  $("#hide").click(function () {
    $(".Abaout").hide();
  });
  $("#show").click(function () {
    $(".Abaout").show();
  });
});
