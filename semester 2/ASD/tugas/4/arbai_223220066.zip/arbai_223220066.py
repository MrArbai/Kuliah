print("Enter your Nilai A :")
A = input()
print("Enter your Nilai B :")
B = input()

print("Sebelum Di Tukar A = " + A +" Dan B = " + B)

C = A
A = B
B = C

print("Setelah Di Tukar A = " + A + " Dan B = " + B)