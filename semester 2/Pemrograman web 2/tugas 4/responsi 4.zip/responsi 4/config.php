<?php

 $Host = 'localhost';
 $Name = 'learn';
 $Username ='root';
 $Password ='bai113399';

 $mysqli = mysqli_connect($Host, $Username, $Password, $Name);

 ?>