def decimal_to_binary(decimal):
    return bin(decimal)

def decimal_to_hexadecimal(decimal):
    return hex(decimal)

def decimal_to_octal(decimal):
    return oct(decimal)
