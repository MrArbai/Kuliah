import math


def addition(a, b):
    return a + b

def subtraction(a, b):
    return a - b

def multiplication(a, b):
    return a * b

def division(a, b):
    return a / b

def exponentiation(a, b):
    return a ** b

def logarithm(a, base):
    return math.log(a, base)

def square_root(a):
    return math.sqrt(a)
