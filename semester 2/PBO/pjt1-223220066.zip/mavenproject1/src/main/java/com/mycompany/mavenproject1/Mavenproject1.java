/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

import Form.frmLogin;

/**
 *
 * @author ITD31
 */
public class Mavenproject1 {
    public static void main(String[] args) {
        new frmLogin().setVisible(true);
    }
}
